<!DOCTYPE html>
<html>
     <head>
<title>asset-management</title>
<link rel="stylesheet" type="text/css" href="../css/search.css">
<script>
        function clearSearchResults() {
            var searchResult = document.getElementById('search-result');
            if (searchResult) {
                searchResult.innerHTML = '';
            }
        }
    </script>
<?php
session_start();
?>
<style>
   
.side{
    text-align: center;
    width: 56.7%;
    height: 100%;
    border: 1px solid blue;
    float: right;
    background:  #035356;;
    color: white;
}
.box input{
    width: 50%;
    margin-bottom: 10px;
    color: white;;
}
.box input[type="text"],input[type="password"]{
    margin-left:90px;
    border: none;
    margin-top:150px;
    background-color: black;
    outline: none;
    height: 85px;
    border-radius: 20px;
}
.cont{
            background-image:url(siggg.jpg);             
}

</style>
</head>
<body>
<div class="main">
<div class="cont">
<div class="mennu">
<ul>
    <?php
 if(isset($_SESSION['id'])){
 ?>
 <?php
}else{
 ?>
 <li><a href="http://localhost/assetmanagement/index.php">Home</a></li>
 <?php
}
 ?>
 <li><a href="http://localhost/assetmanagement/asset/index.php">Asset</a></li>
 <?php
if(isset($_SESSION['id'])){
    ?>
 <?php }else{
 ?>
 <li><a href="http://localhost/assetmanagement/include/admin/dashboard.php">Admin</a></
 <li><a href="http://localhost/assetmanagement/include/users/login.php">Login</a></li>
 <li><a href="http://localhost/assetmanagement/include/users/signup.php">Signup</a></li>
 <li><a href="http://localhost/assetmanagement/include/users/logout.php">Logout</a></li>
   <?php
}
 ?>
 </ul>
 </div>
 <div class="box">
 <form action="search.php" method="GET">
<input type="text" name="search" placeholder="Search by Asset Name">
<button type="submit" onclick="clearSearchResults()">Search</button>
</form>
</div>
 </div>
 <div class="side">
     <?php
include('../include/users/db.php');
 $search = $_GET['search'];
if(isset($_GET['search'])){
$sql = "SELECT * FROM asset WHERE assetname LIKE '%$search%'";
$result = $con->query($sql);

if ($result->num_rows > 0) {
 while ($row = $result->fetch_assoc()) {
 echo "Asset ID: " . $row['id'] . "<br>";
echo "Asset Name: " . $row['assetname'] . "<br>";
echo "Asset Catagory: " . $row['cat'] . "<br><br>";
 echo "Asset Type: " . $row['type'] . "<br><br>";
 echo "Asset Location: " . $row['location'] . "<br><br>";
 echo "Asset Price: " . $row['price'] . "<br><br>";
echo "Usage Life: " . $row['usagelife'] . "<br><br>";
 echo "Start Date: " . $row['startdate'] . "<br><br>";
echo "Disposal Date: " . $row['disposaldate'] . "<br><br>";
 echo "Asset Image: <img src=" . $row[array_keys($row)[count($row)-1]] . "' alt='Asset Image'><br><br>";
}
} else {
echo "No assets found.";
}
}
$con->close();
?>
 </div>
 </div>
 <div class="foter"> <h1>here is footer</h1></div>
</body>
</html>