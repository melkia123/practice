<?php
include('../include/users/db.php');
    if(isset($_POST['updatedata']))
    {   
        $id = $_POST['update_id'];
        
        $assetname= $_POST['assetname'];
        $cat = $_POST['cat'];
        $location= $_POST['location'];
        $price = $_POST['price'];
        $usagelife =$_POST['usagelife'];
        $startdate =$_POST['startdate'];
        $disposaldate =$_POST['disposaldate'];
        $query = "UPDATE asset SET assetname='$assetname', cat='$cat', location='$location', price=' $price',usagelife=' $usagelife',startdate=' $startdate',disposaldate=' $disposaldate' WHERE id='$id'  ";
        $query_run = mysqli_query($con, $query);
s
        if($query_run)
        {
            echo '<script> alert("Data Updated"); </script>';
            header("Location:asset.php");
        }
        else
        {
            echo '<script> alert("Data Not Updated"); </script>';
        }
    }
?>