<?php
include('../include/users/db.php');

if(isset($_POST['view_id'])) {
    $id = $_POST['view_id'];
    $query = "SELECT * FROM asset WHERE id = '$id'";
    $query_run = mysqli_query($con, $query);

    if(mysqli_num_rows($query_run) > 0) {
        foreach($query_run as $row) {
            $response = array(
                "id" => $row['id'],
                "assetname" => $row['assetname'],
                "cat" => $row['cat'],
                "location" => $row['location'],
                "price" => $row['price'],
                "usagelife" => $row['usagelife']
                "startdate" => $row['startdate']
                "disposaldate" => $row['disposaldate']
            );
            echo json_encode($response);
        }
    } else {
        echo "No record found";
    }
}
?>