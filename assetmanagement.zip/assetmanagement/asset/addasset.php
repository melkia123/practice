<?php

include('../include/users/db.php');

if(isset($_POST['addasset']))
{
    $assetname = $_POST['assetname'];
    $cat = $_POST['cat'];
    $location = $_POST['location'];
    $price=$_POST['price'];
    $usagelife = $_POST['usagelife'];
    $startdate= $_POST['startdate'];
    $disposaldate= $_POST['disposaldate'];
    $target="image/".basename($_FILES['image']['name']);
    $image=$_FILES['image']['name'];
    $query = "INSERT INTO asset(assetname,cat,location,price,usagelife,startdate,disposaldate,image) VALUES ('$assetname','$cat','$location','$price','$usagelife','$startdate','$disposaldate','$image')";   
     $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        echo '<script> alert("Data Saved"); </script>';
        header('Location: assetss.php');
    }
    else
    {
        echo '<script> alert("Data Not Saved"); </script>';
    }
}

?>