<?php
// Receive user registration details from about.php
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];

// Save the registration details in the database or send them to the admin
// ...

// Redirect the admin to the dashboard.php page
header("Location: dashbord.php?fname=$fname&lname=$lname&email=$email");
exit();