<!DOCTYPE html>
<html>
<head>
    <title>Assign Asset Page</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/assign_asset.css">
    <style>
        body{
             background-image: url(photo7.jpg);
             background-reapt:non-reapt;
             background-size:cover;
    
        }
        .logo {
    background-color: #333;
    padding: 10px;
}

.logo h1 {
    margin: 0;
    color: white;
}

.menu {
    background-color: #333;
}

.menu ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
}

.menu ul li {
    margin-top:5px;
    height:20px;
    float: left;
    margin-left:250px;
    border:1px solid greenyellow;
}

.menu ul li a {
    display: block;
    color: white;
    text-align: center;
    padding: 3px 5px;
    text-decoration: none;
}

.menu ul li a:hover {
    background-color: #111;
}

.main {
    background-image: url(photo7.jpg);
    height:85vh;
    display:flex;
    justify-content:center;
    align-items:center;

}
.box{
    border:15px solid black;
    height:40vh;
    width:55vh;
}
.container {
    margin-left:20px;
    display: flex;
    flex-direction: column;
    margin-bottom: 20px;
}

.container p {
    color:white;
    text-align:center;
    margin: 0;
}

.container input[type="text"] {
    background-color: greenyellow;
    color:black;
    width: 300px;
    padding: 10px;
    padding-bottom:35px;
    height:18px;
    border-radius:10px;
}

.assign input[type="submit"] {
    padding: 10px 20px;
    background-color: #333;
    color: white;
    border: none;
    margin-left:50px;
}

.footer {
    height:60px;
    background-color: #333;
    padding: 10px;
    color: white;
    text-align: center;
}
.success-message{
    color:white;
    font-size:30px;
    font-weight:bold;
text-align:center;
margin-top:3px;
}
    </style>
</head>
<body>
    <div class="logo">
        <marquee direction="left/right"><h1><a href="http://localhost/assetmanagement" style="color:white">WELCOME TO ASSIGN ASSET PAGE</a></h1></marquee>
    </div>
    <div class="menu">
        <ul>
            <li><a href="http://localhost/assetmanagement/asset/index.php">Asset</a></li>
            <li><a href="http://localhost/assetmanagement/include/admin/manager.php">Manager</a></li>
            <li><a href="http://localhost/assetmanagement/include/users/logout.php">Logout</a></li>
        </ul>
    </div>
    <div class="main">
        <form action="assign_asset.php" method="post">
            <div class="box">
            <div class="container">
                <p>Asset ID</p>
                <input type="text" name="assetid">
                <p>User ID</p>
                <input type="text" name="userid">
            </div>
            <div class="assign">
                <input type="submit" name="assign" value="Assign Asset">
            </div>
            </div>
        </form>
    </div>

    <?php
        include('db.php');
        if(isset($con)) {
            if(isset($_POST['assign'])){
                $assetid=$_POST['assetid'];
                $userid=$_POST['userid'];

                // SQL code to create the necessary column in the database
                $sql = "ALTER TABLE asset ADD COLUMN assigned_to INT(11) DEFAULT NULL";

                // Execute the SQL query
                $exc = mysqli_query($con, $sql);

                if(isset($exc)){
                    $updateSql = "UPDATE asset SET assigned_to = '$userid' WHERE id = '$assetid'";
                    $updateExc = mysqli_query($con, $updateSql);

                    if(isset($updateExc)){
                        echo "<p class='success-message'>Asset Assigned Successfully</p>";
                    } else {
                        echo "Something went wrong while assigning the asset";
                    }
                } else {
                    echo "Something went wrong while creating the column";
                }
            }
        }
    ?>
    </div>
    <div class="footer">Here is the footer</div>

</body>
</html>