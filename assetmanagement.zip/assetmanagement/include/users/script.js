<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title></title>
</head>
<body>
<script type="text/javascript">
var a=10
var b=23.5
Result=a+b
document.write(Result)
</script>
</body>
</html>