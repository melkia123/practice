
<?php
// Initialize the session
session_start();

// Check if the user is logged in, otherwise redirect to the login page


// Include the database connection file
require_once "db.php";

// Define variables and initialize with empty values
$asset_id = $transfer_to_user = "";
$asset_id_err = $transfer_to_user_err = "";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate asset ID
    if(empty(trim($_POST["asset_id"]))){
        $asset_id_err = "Please select an asset to transfer.";
    } else{
        $asset_id = trim($_POST["asset_id"]);
    }
    
    // Validate transfer to user
    if(empty(trim($_POST["transfer_to_user"]))){
        $transfer_to_user_err = "Please select a user to transfer the asset to.";
    } else{
        $transfer_to_user = trim($_POST["transfer_to_user"]);
    }
    
    // Check input errors before transferring the asset
    if(empty($asset_id_err) && empty($transfer_to_user_err)){
        // Update the asset record with the new user
        $sql = "UPDATE asset SET user_id = ? WHERE id = ?";
        
        if($stmt = $mysqli->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("ii", $param_transfer_to_user, $param_asset_id);
            
            // Set parameters
            $param_transfer_to_user = $transfer_to_user;
            $param_asset_id = $asset_id;
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // Redirect to the asset list page
                header("location: assets.php");
                exit;
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            $stmt->close();
        }
    }
    
    // Close connection
    $mysqli->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asset Management System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="wrapper">
        <h2>Transfer Asset</h2>
        <p>Please select the asset and the user to transfer it to.</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group <?php echo (!empty($asset_id_err)) ? 'has-error' : ''; ?>">
                <label>Asset</label>
                <select name="asset_id" class="form-control">
                    <?php
                    // Fetch the assets from the database
                    $sql = "SELECT id, name FROM asset";
                    $result = $mysqli->query($sql);
                    
                    if($result->num_rows > 0){
                        while($row = $result->fetch_assoc()){
                            echo "<option value='" . $row["id"] . "'>" . $row["name"] . "</option>";
                        }
                    }
                    ?>
                </select>
                <span class="help-block"><?php echo $asset_id_err; ?></span>
            </div>
            <div class="form-group <?php echo (!empty($transfer_to_user_err)) ? 'has-error' : ''; ?>">
                <label>Transfer To User</label>
                <select name="transfer_to_user" class="form-control">
                    <?php
                    // Fetch the users from the database
                    $sql = "SELECT id, username FROM assetusers";
                    $result = $mysqli->query($sql);
                    
                    if($result->num_rows > 0){
                        while($row = $result->fetch_assoc()){
echo "<option value='" . $row["id"] . "'>" . $row["username"] . "</option>";
                        }
                    }
                    ?>
                </select>
                <span class="help-block"><?php echo $transfer_to_user_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Transfer">
                <a class="btn btn-link" href="assets.php">Cancel</a>
            </div>
        </form>
    </div>    
</body>
</html>