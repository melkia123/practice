
<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>manager page</title>
        <link rel="stylesheet" type="text/css" href="../../css/index.css">
        <?php
        session_start();
        ?>
        <style>
            .maiin{
    height: 600px;
    background-image: url(photo11.jpg); 
}
h1{
    text-align:center
}
        </style>
    </head>
    <body>
    <div class="mennu">
        <ul>
            <?php
           if(isset($_SESSION['id'])){
            ?>
            <li><a href="http://localhost/assetmanagement/index.php">Home</a></li>
            <li><a href="http://localhost/assetmanagement/include/users/home.php">Userspage</a></li>
            <?php
           }else{
            ?>
            <?php
           }
           ?>
            <li><a href="http://localhost/assetmanagement/asset/index.php">Asset</a></li>
            <?php
            if(isset($_SESSION['id'])){
            ?>
            <li><a href="http://localhost/assetmanagement/asset/search.php">Search</a></li>
            <li><a href="http://localhost/assetmanagement/include/users/logout.php">Logout</a></li>
            <?php
             }else{
                ?>
            </ul>
            </div>
            <?php
        }
        ?>
        </ul>
    </div>

    <div class="maiin">
    <?php
if(isset($_SESSION['id'])){
    if($_SESSION['role']=='manager'){
    ?>
   <marquee behavior="" direction="right"><h1 style="color:white;">WELCOME TO manager </h1></marquee> 
    <h1><a href="http://localhost/assetmanagement/include/users/assign_asset.php" style="color:black;">Asset-Assign</a></h1><br><br><br>
    <h1><a href="http://localhost/assetmanagement/include/users/asset-transfer.php" style="color:black;">Asset Transfer</a></h1>
    <?php
    }else{
    ?>
    <h2>you have no privilage to acces admin <a href="../users/home.php">Go To Home Page </a></h2>
    <?php
    }
    ?>
    <?php
}else{
        header('location:index.php');
}
?>
    </div>
    <div class="foter">here is fo0ter</div>
    </body>
</html>
