<!DOCTYPE html>
<html>
    <head>
        <title>asset-management</title>
        <link rel="stylesheet" type="text/css" href="../../css/index.css">
        <style>
.maiin{
 height:auto
}
.video-container {
 position: relative;
  display: inline-block;
}

.video-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height:100%;
  color: black;
  padding: 20px;
  background-color: rgba(0, 0, 0, 0);
}    
        </style>
    </head>
    <body>
    <div class="mennu">
        <ul>
            <?php
           if(isset($_SESSION['id'])){
            ?>
            
            <?php
           }else{
            ?>
            <li><a href="http://localhost/assetmanagement/index.php">Home</a></li>
            <?php
           }
           ?>
            <li><a href="http://localhost/assetmanagement/asset/index.php">Asset</a></li>
            <?php
            if(isset($_SESSION['id'])){
            ?>
            <li><a href="http://localhost/assetmanagement/asset/lists.php">Assetlist</a></li>
            <li><a href="http://localhost/assetmanagement/about.php">About</a></li>
            <li><a href="http://localhost/assetmanagement/contact.php">Contact</a></li>
            <li><a href="http://localhost/assetmanagement/include/admin/dashboard.php">Admin</a></li>
            <li><a href="http://localhost/assetmanagement/include/users/logout.php">Logout</a></li>
            <?php
             }else{
                ?>
            <li><a href="http://localhost/assetmanagement/include/users/login.php">Login</a></li>
            <li><a href="http://localhost/assetmanagement/include/users/signup.php">Signup</a></li>
            <?php
        }
        ?>
        </ul>
    </div>
    <div class="maiin">
    <div class="video-container">
  <video width="auto" height="auto" autoplay muted loop>
    <source src="video.mp4" type="video/mp4">
  </video>
  <div class="video-overlay">
    <br><br><br><br>
    <marquee behavior="scroll" direction="right"><h1>ASSET MANAGEMENT SYSTEM OF WSU</h1></marquee><br><br><br><br><br><br>
    <marquee behavior="scroll" direction="left"><h1>WELLCOME TO SERVICE</h1></marquee><br><br><br>
  </div>
</div>          
    </div>
    <div class="foter">here is fo0ter</div>
    </body>
</html>