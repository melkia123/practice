<?php
session_start();
$userid=$_GET['id'];
include('../users/db.php');
if(isset($con)){
$vsql="SELECT * FROM assetusers WHERE id='$userid'";
$exc=mysqli_query($con,$vsql);
if(isset($exc)){
$res=mysqli_fetch_array($exc);
$fname=$res['fname'];
$lname=$res['lname'];
$email=$res['email'];
$role=$res['role'];
?>
<h3>Fullname:<?php echo $fname." ".$lname; ?></h3>
<h3>Email: <?php echo $email; ?></h3>
<h3>Role <?php echo $role ;?></h3>
<?php
}
}
?>